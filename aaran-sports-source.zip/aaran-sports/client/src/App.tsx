import Home from "./pages/Home";
export default function App() { return <Home />; }

// AARAN SPORTS is a client-only single page experience.
