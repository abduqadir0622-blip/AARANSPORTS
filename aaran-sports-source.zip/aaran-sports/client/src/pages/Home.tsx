import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  ArrowRight,
  BadgeCheck,
  Bell,
  Calculator,
  Check,
  ChevronDown,
  Clock3,
  Copy,
  Crown,
  Gift,
  Menu,
  MessageCircle,
  Play,
  ShieldCheck,
  Sparkles,
  Star,
  TrendingUp,
  Trophy,
  Users,
  X,
  Zap,
} from "lucide-react";

const TELEGRAM = "https://t.me/aaransports10";
const promoCode = "ARAN10H";

const notifications = [
  { name: "Farhaan", amount: "$250.00", note: "bonus ah helay" },
  { name: "Caasha", amount: "$450.00", note: "faa'iido ah heshay" },
  { name: "Maxamed", amount: "$800.00", note: "VIP Bonus helay" },
  { name: "Sumaya", amount: "$1,250.00", note: "ku faa'iiday" },
  { name: "Abdi", amount: "$350.00", note: "bonus helay" },
  { name: "Hodhan", amount: "$1,050.00", note: "VIP Reward heshay" },
];

const faqs = [
  ["Sidee ayaan u isticmaalaa ARAN10H?", "Ku biir Telegram VIP, fur adeegga aad rabto, kadib geli code-ka ARAN10H marka lagu weydiiyo. Faa'iidadaada waxaa lagu xisaabinayaa isla markiiba."],
  ["Ma lacag baa ku baxaysa ku biirista Telegram?", "Maya. Ku biirista channel-ka AARAN SPORTS Telegram waa bilaash. Halkaas ayaad ka heli doontaa updates, fursado iyo hagitaan."],
  ["Goorma ayaa VIP benefits-ku shaqeeyaan?", "Benefits-ku waxay shaqeeyaan marka code-ka la aqbalo. Haddii aad wax su'aal ah qabto, kooxda support-ka Telegram ayaa ku caawinaysa."],
  ["AARAN SPORTS ma dammaanad qaadaa natiijo?", "Maya. Talooyinka iyo rewards-ku ma aha dammaanad guul. Ku ciyaar si masuuliyad leh, ogowna shuruudaha adeegga aad isticmaalayso."],
];

function scrollToId(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

export default function Home() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [faqOpen, setFaqOpen] = useState<number | null>(0);
  const [activeNotification, setActiveNotification] = useState(0);
  const [stake, setStake] = useState(100);
  const [copied, setCopied] = useState(false);

  const bonus = useMemo(() => Math.round(stake * 0.1), [stake]);

  useEffect(() => {
    const timer = window.setInterval(() => setActiveNotification((index) => (index + 1) % notifications.length), 4800);
    return () => window.clearInterval(timer);
  }, []);

  const copyPromo = async () => {
    try {
      await navigator.clipboard.writeText(promoCode);
      setCopied(true);
      toast.success("VIP Promo Code Copied!", { description: "ARAN10H diyaar ayuu kuu yahay." });
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Copy failed", { description: "Fadlan gacanta ku qor ARAN10H." });
    }
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#060708] text-white selection:bg-[#ef1d25] selection:text-white">
      <div className="noise" />
      <div className="top-line" />

      <header className="fixed left-0 right-0 top-0 z-50 border-b border-white/[0.08] bg-[#060708]/75 backdrop-blur-xl">
        <div className="container flex h-[78px] items-center justify-between">
          <button onClick={() => scrollToId("home")} className="brand-lockup group flex items-center gap-3" aria-label="AARAN SPORTS home">
            <div className="logo-shell"><img src="/manus-storage/aaran-sports-logo_d2ef07ff.png" alt="Aaran Sports" /></div>
            <div className="hidden sm:block text-left"><div className="font-display text-[15px] font-bold tracking-[0.18em] text-white">AARAN SPORTS</div><div className="text-[9px] font-bold uppercase tracking-[0.28em] text-[#ef1d25]">The VIP edge</div></div>
          </button>
          <nav className="hidden items-center gap-8 lg:flex" aria-label="Main navigation">
            {[['Home','home'],['VIP Benefits','benefits'],['Services','services'],['Telegram','telegram'],['FAQ','faq']].map(([label,id]) => <button key={id} onClick={() => scrollToId(id)} className="nav-link">{label}</button>)}
          </nav>
          <div className="hidden items-center gap-3 lg:flex"><span className="live-dot"><i /> Live now</span><a className="button-primary px-4 py-2.5 text-[11px]" href={TELEGRAM} target="_blank" rel="noreferrer">Join Telegram VIP <ArrowRight size={15} /></a></div>
          <button className="rounded-lg border border-white/10 p-2 text-white lg:hidden" onClick={() => setMobileOpen((v) => !v)} aria-label="Toggle menu">{mobileOpen ? <X size={21} /> : <Menu size={21} />}</button>
        </div>
        {mobileOpen && <div className="border-t border-white/10 bg-[#080a0b] px-5 py-4 lg:hidden"><div className="flex flex-col gap-2">{[['Home','home'],['VIP Benefits','benefits'],['Services','services'],['Telegram','telegram'],['FAQ','faq']].map(([label,id]) => <button key={id} onClick={() => { scrollToId(id); setMobileOpen(false); }} className="rounded-lg px-3 py-3 text-left text-sm text-white/65 hover:bg-white/5 hover:text-white">{label}</button>)}<a href={TELEGRAM} target="_blank" rel="noreferrer" className="button-primary mt-2 justify-center">Join Telegram VIP <ArrowRight size={15} /></a></div></div>}
      </header>

      <main id="home">
        <section className="hero-section relative pt-28">
          <div className="hero-orb hero-orb-red" /><div className="hero-orb hero-orb-gold" />
          <div className="container relative z-10 grid min-h-[720px] items-center gap-12 pb-20 pt-16 lg:grid-cols-[1.05fr_.95fr] lg:pb-28 lg:pt-20">
            <div className="max-w-2xl">
              <div className="eyebrow mb-7"><span className="eyebrow-pulse" /> Somalia's #1 VIP sports community <span className="eyebrow-line" /></div>
              <h1 className="font-display text-[clamp(3.4rem,8vw,7.2rem)] font-black leading-[.9] tracking-[-.075em]">Play smarter.<br /><span className="gradient-text">Win bigger.</span></h1>
              <p className="mt-8 max-w-xl text-base leading-8 text-white/55 sm:text-lg">Ku biir AARAN SPORTS VIP — meesha ay isku yimaadaan fursadaha kulul, insights-ka gaarka ah iyo rewards-ka aan caadiga ahayn.</p>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row"><a className="button-primary justify-center sm:justify-start" href={TELEGRAM} target="_blank" rel="noreferrer"><MessageCircle size={18} /> Join Telegram VIP <ArrowRight size={16} /></a><button className="button-ghost justify-center sm:justify-start" onClick={() => scrollToId("promo")}><Gift size={17} /> Unlock ARAN10H</button></div>
              <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 text-[11px] font-semibold uppercase tracking-[0.14em] text-white/45"><span className="flex items-center gap-2"><ShieldCheck size={16} className="text-[#ef1d25]" /> Trusted community</span><span className="flex items-center gap-2"><Users size={16} className="text-[#ef1d25]" /> 25K+ members</span><span className="flex items-center gap-2"><Clock3 size={16} className="text-[#ef1d25]" /> Daily updates</span></div>
            </div>
            <div className="relative mx-auto w-full max-w-[520px] lg:ml-auto">
              <div className="hero-card-shine" />
              <div className="stadium-card glass-panel">
                <div className="stadium-grid" /><div className="stadium-ring ring-one" /><div className="stadium-ring ring-two" />
                <div className="relative z-10 flex items-start justify-between"><span className="card-kicker">VIP ACCESS / 10</span><span className="live-badge"><span /> LIVE</span></div>
                <div className="relative z-10 mt-24"><div className="text-xs font-bold uppercase tracking-[.28em] text-white/35">Your advantage</div><div className="mt-3 font-display text-5xl font-black tracking-[-.06em] text-white sm:text-6xl">10<span className="text-[#ef1d25]">%</span></div><div className="mt-2 text-sm text-white/45">extra value with code ARAN10H</div></div>
                <div className="relative z-10 mt-14 grid grid-cols-3 gap-2"><div className="mini-stat"><span>Members</span><strong>25K+</strong></div><div className="mini-stat"><span>Signals</span><strong>24/7</strong></div><div className="mini-stat"><span>Rank</span><strong>#01</strong></div></div>
                <div className="absolute bottom-5 right-5 rounded-full border border-[#ef1d25]/30 bg-[#ef1d25]/10 p-3 text-[#ef1d25]"><Trophy size={20} /></div>
              </div>
              <div className="float-chip chip-top"><Sparkles size={15} className="text-[#f7c86a]" /> <span>VIP only</span></div><div className="float-chip chip-bottom"><span className="green-dot" /> <span>+1,250.00 today</span></div>
            </div>
          </div>
          <div className="hero-marquee"><div>VIP INSIGHTS <span>✦</span> SMARTER MOVES <span>✦</span> DAILY EDGE <span>✦</span> AARAN SPORTS <span>✦</span> VIP INSIGHTS <span>✦</span> SMARTER MOVES <span>✦</span> DAILY EDGE <span>✦</span></div></div>
        </section>

        <section id="promo" className="container relative z-10 -mt-1 py-16 sm:py-24"><div className="promo-wrap"><div className="promo-glow" /><div className="relative grid items-center gap-8 p-6 sm:p-9 lg:grid-cols-[1fr_auto] lg:p-12"><div><div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[.25em] text-[#f7c86a]"><Zap size={14} fill="currentColor" /> Limited VIP drop</div><h2 className="mt-3 font-display text-3xl font-black tracking-[-.04em] sm:text-4xl">Your secret advantage is <span className="text-[#f7c86a]">ARAN10H</span></h2><p className="mt-3 max-w-xl text-sm leading-7 text-white/50">Geli code-kaaga gaarka ah. Copy, isticmaal, oo hel 10% extra value marka aad ku biirto AARAN SPORTS VIP.</p></div><div className="flex flex-col gap-3 sm:flex-row lg:flex-col"><button onClick={copyPromo} className="promo-code"><span>{promoCode}</span><span className="promo-copy">{copied ? <Check size={16} /> : <Copy size={16} />} {copied ? "Copied" : "Copy code"}</span></button><a href={TELEGRAM} target="_blank" rel="noreferrer" className="button-primary justify-center">Activate on Telegram <ArrowRight size={15} /></a></div></div></div></section>

        <section id="benefits" className="container py-14 sm:py-24"><div className="section-head"><div><div className="section-label">01 / Why Aaran</div><h2 className="section-title">An edge built<br /><span>for you.</span></h2></div><p className="section-copy">Wax walba hal meel. Faa'iidooyin la taaban karo iyo adeeg VIP ah oo loo dhisay dadka doonaya inay ka horeeyaan ciyaarta.</p></div><div className="mt-12 grid gap-4 md:grid-cols-3"><BenefitCard icon={<Crown />} number="01" title="VIP Tiers" text="Hel access heerar kala duwan leh, laga bilaabo Starter ilaa Elite. Kor u kac marka aad gaarto heerka xiga." /><BenefitCard icon={<TrendingUp />} number="02" title="ARAN10H Edge" text="Isticmaal promo code-kaaga gaarka ah oo fur 10% extra value iyo offers qarsoon." /><BenefitCard icon={<Bell />} number="03" title="Live Alerts" text="Ha seegin fursad. Alerts iyo insights cusub ayaa kuu imanaya waqtiga saxda ah." /></div></section>

        <section id="services" className="border-y border-white/[.06] bg-[#0a0d0e] py-16 sm:py-24"><div className="container"><div className="grid items-start gap-12 lg:grid-cols-[.8fr_1.2fr]"><div><div className="section-label">02 / Your toolkit</div><h2 className="section-title mt-4">Built to make<br /><span>every move count.</span></h2><p className="section-copy mt-6">AARAN SPORTS ma aha channel kaliya. Waa toolkit dhamaystiran oo kuu diyaariya inaad si kalsooni leh u dhaqaaqdo.</p><a href={TELEGRAM} target="_blank" rel="noreferrer" className="button-ghost mt-8 inline-flex">Explore the VIP room <ArrowRight size={16} /></a></div><div className="grid gap-4 sm:grid-cols-2"><ServiceCard icon={<Zap />} title="Hot Picks" text="Fursadaha kulul iyo watchlist-ka maalinlaha ah." /><ServiceCard icon={<ShieldCheck />} title="Smart Guidance" text="Habab fudud oo kaa caawinaya go'aan fiican." /><ServiceCard icon={<Users />} title="Private Community" text="La hadal dadka isku fikirka ah, 24/7." /><ServiceCard icon={<Gift />} title="VIP Rewards" text="Offers gaar ah iyo rewards xilliyeed." /></div></div></div></section>

        <section className="container py-16 sm:py-24"><div className="section-head"><div><div className="section-label">03 / Run the numbers</div><h2 className="section-title">See your<br /><span>VIP upside.</span></h2></div><p className="section-copy">Tijaabi calculator-ka oo arag sida 10% ARAN10H bonus-ku uga muuqdo value-gaaga.</p></div><div className="calculator mt-12 grid gap-8 p-6 sm:p-10 lg:grid-cols-[1fr_.85fr] lg:items-center"><div><div className="flex items-center gap-3"><div className="icon-box"><Calculator size={20} /></div><div><div className="text-xs font-black uppercase tracking-[.22em] text-white/35">VIP calculator</div><div className="font-display text-xl font-bold">Set your starting value</div></div></div><div className="mt-10 flex items-end justify-between"><span className="text-sm text-white/45">Your amount</span><strong className="font-display text-4xl text-white">${stake}</strong></div><input className="range mt-5" type="range" min="50" max="1000" step="50" value={stake} onChange={(e) => setStake(Number(e.target.value))} aria-label="Your amount" /><div className="mt-4 flex justify-between text-[10px] font-bold uppercase tracking-widest text-white/25"><span>$50</span><span>$1,000</span></div></div><div className="result-box"><div className="text-xs font-bold uppercase tracking-[.2em] text-white/40">With ARAN10H</div><div className="mt-3 font-display text-6xl font-black tracking-[-.06em] text-[#f7c86a]">+${bonus}</div><div className="mt-2 text-sm text-white/45">estimated VIP bonus value</div><div className="mt-8 flex items-center gap-2 border-t border-white/10 pt-5 text-xs text-white/45"><BadgeCheck size={16} className="text-[#f7c86a]" /> Instant code activation</div></div></div></section>

        <section id="telegram" className="container pb-16 sm:pb-24"><div className="telegram-banner"><div className="absolute -right-16 -top-24 h-72 w-72 rounded-full bg-[#ef1d25]/20 blur-3xl" /><div className="relative z-10 flex flex-col justify-between gap-8 p-7 sm:p-10 lg:flex-row lg:items-center lg:p-14"><div><div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[.25em] text-[#ef1d25]"><MessageCircle size={15} fill="currentColor" /> Telegram VIP room</div><h2 className="mt-4 max-w-2xl font-display text-3xl font-black tracking-[-.05em] sm:text-5xl">Your next smart move<br /><span className="text-[#f7c86a]">starts here.</span></h2><p className="mt-4 max-w-xl text-sm leading-7 text-white/55">Ku biir kumanaan members ah oo maalin kasta raadinaya edge-ka xiga.</p></div><a href={TELEGRAM} target="_blank" rel="noreferrer" className="button-primary whitespace-nowrap">Open Telegram <ArrowRight size={16} /></a></div></div></section>

        <section className="border-t border-white/[.06] bg-[#080a0b] py-16 sm:py-24"><div className="container"><div className="section-head"><div><div className="section-label">04 / The community</div><h2 className="section-title">Loved by the<br /><span>VIP crowd.</span></h2></div><div className="flex items-center gap-3"><div className="flex text-[#f7c86a]">{[1,2,3,4,5].map((i) => <Star key={i} size={16} fill="currentColor" />)}</div><span className="text-xs text-white/40">4.9 / 5 from members</span></div></div><div className="mt-12 grid gap-4 md:grid-cols-3"><Testimonial name="Sahra M." role="VIP Member" quote="AARAN SPORTS waxay iga dhigtay inaan si ka duwan u arko fursadaha. Updates-ku waa degdeg, community-guna waa real." /><Testimonial name="Cabdiraxmaan A." role="Elite Member" quote="Waxa aan jeclahay waa simplicity-ga. Hal meel ayaan ka helaa alerts, insights iyo kooxda Telegram." /><Testimonial name="Nimco H." role="VIP Member" quote="ARAN10H waa easy in la isticmaalo, team-kuna mar walba way ka jawaabaan. Truly feels premium." /></div></div></section>

        <section id="faq" className="container py-16 sm:py-24"><div className="grid gap-12 lg:grid-cols-[.8fr_1.2fr]"><div><div className="section-label">05 / FAQ</div><h2 className="section-title mt-4">Questions?<br /><span>We got you.</span></h2><p className="section-copy mt-6">Wax walba oo aad u baahan tahay inaad ogaato ka hor intaadan gelin VIP room-ka.</p></div><div className="space-y-3">{faqs.map(([question, answer], index) => <div className="faq-item" key={question}><button className="flex w-full items-center justify-between gap-5 py-5 text-left" onClick={() => setFaqOpen(faqOpen === index ? null : index)}><span className="font-display text-lg font-bold">{question}</span><ChevronDown size={18} className={`shrink-0 text-[#ef1d25] transition-transform ${faqOpen === index ? "rotate-180" : ""}`} /></button>{faqOpen === index && <div className="pb-5 pr-10 text-sm leading-7 text-white/45">{answer}</div>}</div>)}</div></div></section>
      </main>

      <footer className="border-t border-white/[.07] bg-[#050607]"><div className="container flex flex-col gap-8 py-10 sm:py-14 lg:flex-row lg:items-end lg:justify-between"><div><div className="flex items-center gap-3"><div className="logo-shell small"><img src="/manus-storage/aaran-sports-logo_d2ef07ff.png" alt="Aaran Sports" /></div><div className="font-display text-sm font-bold tracking-[.16em]">AARAN SPORTS</div></div><p className="mt-5 max-w-sm text-xs leading-6 text-white/35">The VIP edge for smarter moves. Built for the community, powered by ambition.</p></div><div className="flex flex-wrap gap-x-6 gap-y-3 text-xs text-white/40"><button onClick={() => scrollToId("home")} className="hover:text-white">Home</button><button onClick={() => scrollToId("benefits")} className="hover:text-white">Benefits</button><a href={TELEGRAM} target="_blank" rel="noreferrer" className="hover:text-white">Telegram</a><button onClick={() => scrollToId("faq")} className="hover:text-white">FAQ</button></div><div className="text-xs text-white/25">© 2025 AARAN SPORTS. Play responsibly.</div></div><div className="container border-t border-white/[.05] py-5 text-[10px] leading-5 text-white/25">Disclaimer: AARAN SPORTS provides information and community access only. Rewards, offers and results may vary. Please use all services responsibly and follow local laws.</div></footer>

      <div className="notification-pop" key={activeNotification}><div className="notification-icon"><Bell size={16} /></div><div><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.15em] text-[#f7c86a]"><span className="green-dot" /> Just now</div><p className="mt-1 text-xs leading-5 text-white/70"><strong className="text-white">{notifications[activeNotification].name}</strong> {notifications[activeNotification].note} <strong className="text-[#f7c86a]">{notifications[activeNotification].amount}</strong></p></div></div>
    </div>
  );
}

function BenefitCard({ icon, number, title, text }: { icon: React.ReactNode; number: string; title: string; text: string }) { return <div className="benefit-card"><div className="flex items-start justify-between"><div className="icon-box red">{icon}</div><span className="font-display text-sm font-bold text-white/20">{number}</span></div><h3 className="mt-9 font-display text-2xl font-bold">{title}</h3><p className="mt-3 text-sm leading-7 text-white/45">{text}</p><div className="card-arrow"><ArrowRight size={16} /></div></div> }
function ServiceCard({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) { return <div className="service-card"><div className="icon-box">{icon}</div><h3 className="mt-7 font-display text-xl font-bold">{title}</h3><p className="mt-2 text-sm leading-6 text-white/45">{text}</p></div> }
function Testimonial({ name, role, quote }: { name: string; role: string; quote: string }) { return <div className="testimonial"><div className="flex items-center gap-1 text-[#f7c86a]">{[1,2,3,4,5].map((i) => <Star key={i} size={13} fill="currentColor" />)}</div><p className="mt-6 text-sm leading-7 text-white/65">“{quote}”</p><div className="mt-8 flex items-center gap-3"><div className="avatar">{name[0]}</div><div><div className="text-sm font-bold">{name}</div><div className="text-[10px] uppercase tracking-widest text-white/30">{role}</div></div></div></div> }

